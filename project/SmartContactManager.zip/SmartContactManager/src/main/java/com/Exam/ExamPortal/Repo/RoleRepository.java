package com.Exam.ExamPortal.Repo;

import com.Exam.ExamPortal.Modelss.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Long> {
}
